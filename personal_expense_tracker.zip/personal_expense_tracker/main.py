from fastapi import FastAPI

from database import Base, engine
from models import User, Category, Expense

from routers import users
from routers import categories
from routers import expenses
from routers import reports


app = FastAPI(
    title="Personal Expense Tracker & Spending Analytics System",
    description="API for managing personal expenses and generating spending reports",
    version="1.0.0"
)


Base.metadata.create_all(bind=engine)


app.include_router(
    users.router,
    prefix="/users",
    tags=["Users"]
)

app.include_router(
    categories.router,
    prefix="/categories",
    tags=["Categories"]
)

app.include_router(
    expenses.router,
    prefix="/expenses",
    tags=["Expenses"]
)

app.include_router(
    reports.router,
    prefix="/reports",
    tags=["Spending Reports"]
)


@app.get("/")
def root():
    return {
        "message": "Personal Expense Tracker API is running",
        "database": "SQLite",
        "docs": "/docs"
    }