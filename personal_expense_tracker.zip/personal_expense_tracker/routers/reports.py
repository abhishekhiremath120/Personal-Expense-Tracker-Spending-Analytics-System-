from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from database import get_db
from models import Expense, Category
from schemas import MonthlyReport, CategoryReport

router = APIRouter()


@router.get("/monthly", response_model=list[MonthlyReport])
def monthly_report(
    year: int = Query(..., ge=2000, le=2100),
    db: Session = Depends(get_db)
):
    results = (
        db.query(
            func.strftime("%Y-%m", Expense.expense_date).label("month"),
            func.sum(Expense.amount).label("total_spending"),
            func.count(Expense.id).label("expense_count")
        )
        .filter(
            func.strftime("%Y", Expense.expense_date) == str(year)
        )
        .group_by(
            func.strftime("%Y-%m", Expense.expense_date)
        )
        .order_by(
            func.strftime("%Y-%m", Expense.expense_date)
        )
        .all()
    )

    return [
        MonthlyReport(
            month=result.month,
            total_spending=float(result.total_spending or 0),
            expense_count=result.expense_count
        )
        for result in results
    ]


@router.get("/by-category", response_model=list[CategoryReport])
def category_report(
    db: Session = Depends(get_db)
):
    results = (
        db.query(
            Category.id.label("category_id"),
            Category.name.label("category_name"),
            func.sum(Expense.amount).label("total_spending"),
            func.count(Expense.id).label("expense_count")
        )
        .join(
            Expense,
            Category.id == Expense.category_id
        )
        .group_by(
            Category.id,
            Category.name
        )
        .order_by(
            func.sum(Expense.amount).desc()
        )
        .all()
    )

    return [
        CategoryReport(
            category_id=result.category_id,
            category_name=result.category_name,
            total_spending=float(result.total_spending or 0),
            expense_count=result.expense_count
        )
        for result in results
    ]