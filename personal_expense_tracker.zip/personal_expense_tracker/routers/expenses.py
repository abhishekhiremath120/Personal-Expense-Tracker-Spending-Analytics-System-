from datetime import date

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from database import get_db
from models import Expense, User, Category
from schemas import ExpenseCreate, ExpenseUpdate, ExpenseResponse

router = APIRouter()


@router.post("", response_model=ExpenseResponse, status_code=201)
def create_expense(
    data: ExpenseCreate,
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.id == data.user_id).first()

    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found"
        )

    category = (
        db.query(Category)
        .filter(Category.id == data.category_id)
        .first()
    )

    if not category:
        raise HTTPException(
            status_code=404,
            detail="Category not found"
        )

    if data.amount <= 0:
        raise HTTPException(
            status_code=400,
            detail="Expense amount must be greater than 0"
        )

    expense = Expense(
        user_id=data.user_id,
        category_id=data.category_id,
        amount=data.amount,
        description=data.description,
        expense_date=data.expense_date
    )

    db.add(expense)
    db.commit()
    db.refresh(expense)

    return expense


@router.get("", response_model=list[ExpenseResponse])
def get_expenses(
    user_id: int | None = Query(default=None),
    category_id: int | None = Query(default=None),
    start_date: date | None = Query(default=None),
    end_date: date | None = Query(default=None),
    page: int = Query(default=1, ge=1),
    limit: int = Query(default=10, ge=1, le=100),
    db: Session = Depends(get_db)
):
    query = db.query(Expense)

    if user_id is not None:
        query = query.filter(Expense.user_id == user_id)

    if category_id is not None:
        query = query.filter(Expense.category_id == category_id)

    if start_date is not None:
        query = query.filter(
            Expense.expense_date >= start_date
        )

    if end_date is not None:
        query = query.filter(
            Expense.expense_date <= end_date
        )

    offset = (page - 1) * limit

    expenses = (
        query
        .order_by(Expense.expense_date.desc())
        .offset(offset)
        .limit(limit)
        .all()
    )

    return expenses


@router.get("/{expense_id}", response_model=ExpenseResponse)
def get_expense(
    expense_id: int,
    db: Session = Depends(get_db)
):
    expense = (
        db.query(Expense)
        .filter(Expense.id == expense_id)
        .first()
    )

    if not expense:
        raise HTTPException(
            status_code=404,
            detail="Expense not found"
        )

    return expense


@router.put("/{expense_id}", response_model=ExpenseResponse)
def update_expense(
    expense_id: int,
    data: ExpenseUpdate,
    db: Session = Depends(get_db)
):
    expense = (
        db.query(Expense)
        .filter(Expense.id == expense_id)
        .first()
    )

    if not expense:
        raise HTTPException(
            status_code=404,
            detail="Expense not found"
        )

    if data.user_id is not None:
        user = (
            db.query(User)
            .filter(User.id == data.user_id)
            .first()
        )

        if not user:
            raise HTTPException(
                status_code=404,
                detail="User not found"
            )

        expense.user_id = data.user_id

    if data.category_id is not None:
        category = (
            db.query(Category)
            .filter(Category.id == data.category_id)
            .first()
        )

        if not category:
            raise HTTPException(
                status_code=404,
                detail="Category not found"
            )

        expense.category_id = data.category_id

    if data.amount is not None:
        if data.amount <= 0:
            raise HTTPException(
                status_code=400,
                detail="Expense amount must be greater than 0"
            )

        expense.amount = data.amount

    if data.description is not None:
        expense.description = data.description

    if data.expense_date is not None:
        expense.expense_date = data.expense_date

    db.commit()
    db.refresh(expense)

    return expense


@router.delete("/{expense_id}")
def delete_expense(
    expense_id: int,
    db: Session = Depends(get_db)
):
    expense = (
        db.query(Expense)
        .filter(Expense.id == expense_id)
        .first()
    )

    if not expense:
        raise HTTPException(
            status_code=404,
            detail="Expense not found"
        )

    db.delete(expense)
    db.commit()

    return {
        "message": "Expense deleted successfully"
    }