from pydantic import BaseModel, EmailStr, Field, ConfigDict
from datetime import date, datetime
from typing import Optional


class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr


class UserResponse(BaseModel):
    id: int
    name: str
    email: EmailStr
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class CategoryCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    description: Optional[str] = None


class CategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ExpenseCreate(BaseModel):
    user_id: int = Field(..., gt=0)
    category_id: int = Field(..., gt=0)
    amount: float = Field(..., gt=0)
    description: Optional[str] = None
    expense_date: date


class ExpenseUpdate(BaseModel):
    user_id: Optional[int] = Field(None, gt=0)
    category_id: Optional[int] = Field(None, gt=0)
    amount: Optional[float] = Field(None, gt=0)
    description: Optional[str] = None
    expense_date: Optional[date] = None


class ExpenseResponse(BaseModel):
    id: int
    user_id: int
    category_id: int
    amount: float
    description: Optional[str]
    expense_date: date
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class MonthlyReport(BaseModel):
    month: str
    total_spending: float
    expense_count: int


class CategoryReport(BaseModel):
    category_id: int
    category_name: str
    total_spending: float
    expense_count: int