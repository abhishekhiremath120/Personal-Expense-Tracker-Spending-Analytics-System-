def create_user(client):
    response = client.post(
        "/users",
        json={
            "name": "Abhishek",
            "email": "abhishek@example.com"
        }
    )

    return response.json()["id"]


def create_category(client, name):
    response = client.post(
        "/categories",
        json={
            "name": name,
            "description": f"{name} expenses"
        }
    )

    return response.json()["id"]


def add_expense(
    client,
    user_id,
    category_id,
    amount,
    expense_date
):
    return client.post(
        "/expenses",
        json={
            "user_id": user_id,
            "category_id": category_id,
            "amount": amount,
            "description": "Test expense",
            "expense_date": expense_date
        }
    )


def test_monthly_report(client):
    user_id = create_user(client)
    category_id = create_category(client, "Food")

    add_expense(
        client,
        user_id,
        category_id,
        500,
        "2026-09-05"
    )

    add_expense(
        client,
        user_id,
        category_id,
        1000,
        "2026-09-10"
    )

    response = client.get(
        "/reports/monthly?year=2026"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["month"] == "2026-09"
    assert data[0]["total_spending"] == 1500
    assert data[0]["expense_count"] == 2


def test_category_report(client):
    user_id = create_user(client)

    food_id = create_category(
        client,
        "Food"
    )

    travel_id = create_category(
        client,
        "Travel"
    )

    add_expense(
        client,
        user_id,
        food_id,
        1000,
        "2026-09-05"
    )

    add_expense(
        client,
        user_id,
        food_id,
        500,
        "2026-09-06"
    )

    add_expense(
        client,
        user_id,
        travel_id,
        3000,
        "2026-09-07"
    )

    response = client.get(
        "/reports/by-category"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 2

    assert data[0]["category_name"] == "Travel"
    assert data[0]["total_spending"] == 3000
    assert data[0]["expense_count"] == 1

    assert data[1]["category_name"] == "Food"
    assert data[1]["total_spending"] == 1500
    assert data[1]["expense_count"] == 2