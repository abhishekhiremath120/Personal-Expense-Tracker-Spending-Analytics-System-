def test_create_category(client):
    response = client.post(
        "/categories",
        json={
            "name": "Food",
            "description": "Food and dining expenses"
        }
    )

    assert response.status_code == 201

    data = response.json()

    assert data["name"] == "Food"
    assert data["description"] == "Food and dining expenses"


def test_get_categories(client):
    client.post(
        "/categories",
        json={
            "name": "Travel",
            "description": "Travel expenses"
        }
    )

    response = client.get("/categories")

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["name"] == "Travel"


def test_get_category(client):
    create_response = client.post(
        "/categories",
        json={
            "name": "Shopping",
            "description": "Shopping expenses"
        }
    )

    category_id = create_response.json()["id"]

    response = client.get(f"/categories/{category_id}")

    assert response.status_code == 200
    assert response.json()["id"] == category_id


def test_category_not_found(client):
    response = client.get("/categories/999")

    assert response.status_code == 404
    assert response.json()["detail"] == "Category not found"


def test_duplicate_category(client):
    category = {
        "name": "Bills",
        "description": "Monthly bills"
    }

    first_response = client.post(
        "/categories",
        json=category
    )

    assert first_response.status_code == 201

    second_response = client.post(
        "/categories",
        json=category
    )

    assert second_response.status_code == 400
    assert second_response.json()["detail"] == "Category already exists"