def test_create_user(client):
    response = client.post(
        "/users",
        json={
            "name": "Abhishek",
            "email": "abhishek@example.com"
        }
    )

    assert response.status_code == 201

    data = response.json()

    assert data["name"] == "Abhishek"
    assert data["email"] == "abhishek@example.com"
    assert "id" in data


def test_get_users(client):
    client.post(
        "/users",
        json={
            "name": "Abhishek",
            "email": "abhishek@example.com"
        }
    )

    response = client.get("/users")

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["name"] == "Abhishek"


def test_get_user(client):
    create_response = client.post(
        "/users",
        json={
            "name": "Rahul",
            "email": "rahul@example.com"
        }
    )

    user_id = create_response.json()["id"]

    response = client.get(f"/users/{user_id}")

    assert response.status_code == 200
    assert response.json()["id"] == user_id


def test_user_not_found(client):
    response = client.get("/users/999")

    assert response.status_code == 404
    assert response.json()["detail"] == "User not found"


def test_duplicate_email(client):
    user = {
        "name": "Abhishek",
        "email": "abhishek@example.com"
    }

    first_response = client.post("/users", json=user)

    assert first_response.status_code == 201

    second_response = client.post("/users", json=user)

    assert second_response.status_code == 400
    assert second_response.json()["detail"] == "Email already registered"


def test_invalid_email(client):
    response = client.post(
        "/users",
        json={
            "name": "Abhishek",
            "email": "invalid-email"
        }
    )

    assert response.status_code == 422