def create_user(client):
    response = client.post(
        "/users",
        json={
            "name": "Abhishek",
            "email": "abhishek@example.com"
        }
    )

    return response.json()["id"]


def create_category(client):
    response = client.post(
        "/categories",
        json={
            "name": "Food",
            "description": "Food expenses"
        }
    )

    return response.json()["id"]


def create_expense(client, user_id, category_id):
    response = client.post(
        "/expenses",
        json={
            "user_id": user_id,
            "category_id": category_id,
            "amount": 500.50,
            "description": "Lunch",
            "expense_date": "2026-09-10"
        }
    )

    return response


def test_create_expense(client):
    user_id = create_user(client)
    category_id = create_category(client)

    response = create_expense(
        client,
        user_id,
        category_id
    )

    assert response.status_code == 201

    data = response.json()

    assert data["user_id"] == user_id
    assert data["category_id"] == category_id
    assert data["amount"] == 500.50
    assert data["description"] == "Lunch"


def test_get_expense(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_response = create_expense(
        client,
        user_id,
        category_id
    )

    expense_id = create_response.json()["id"]

    response = client.get(
        f"/expenses/{expense_id}"
    )

    assert response.status_code == 200
    assert response.json()["id"] == expense_id


def test_expense_not_found(client):
    response = client.get("/expenses/999")

    assert response.status_code == 404
    assert response.json()["detail"] == "Expense not found"


def test_invalid_expense_amount(client):
    user_id = create_user(client)
    category_id = create_category(client)

    response = client.post(
        "/expenses",
        json={
            "user_id": user_id,
            "category_id": category_id,
            "amount": -100,
            "description": "Invalid expense",
            "expense_date": "2026-09-10"
        }
    )

    assert response.status_code == 422


def test_zero_expense_amount(client):
    user_id = create_user(client)
    category_id = create_category(client)

    response = client.post(
        "/expenses",
        json={
            "user_id": user_id,
            "category_id": category_id,
            "amount": 0,
            "description": "Zero expense",
            "expense_date": "2026-09-10"
        }
    )

    assert response.status_code == 422


def test_invalid_user(client):
    category_id = create_category(client)

    response = client.post(
        "/expenses",
        json={
            "user_id": 999,
            "category_id": category_id,
            "amount": 500,
            "description": "Test",
            "expense_date": "2026-09-10"
        }
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "User not found"


def test_invalid_category(client):
    user_id = create_user(client)

    response = client.post(
        "/expenses",
        json={
            "user_id": user_id,
            "category_id": 999,
            "amount": 500,
            "description": "Test",
            "expense_date": "2026-09-10"
        }
    )

    assert response.status_code == 404
    assert response.json()["detail"] == "Category not found"


def test_update_expense(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_response = create_expense(
        client,
        user_id,
        category_id
    )

    expense_id = create_response.json()["id"]

    response = client.put(
        f"/expenses/{expense_id}",
        json={
            "amount": 750,
            "description": "Updated lunch"
        }
    )

    assert response.status_code == 200

    data = response.json()

    assert data["amount"] == 750
    assert data["description"] == "Updated lunch"


def test_delete_expense(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_response = create_expense(
        client,
        user_id,
        category_id
    )

    expense_id = create_response.json()["id"]

    response = client.delete(
        f"/expenses/{expense_id}"
    )

    assert response.status_code == 200
    assert response.json()["message"] == "Expense deleted successfully"

    get_response = client.get(
        f"/expenses/{expense_id}"
    )

    assert get_response.status_code == 404


def test_filter_by_user(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_expense(
        client,
        user_id,
        category_id
    )

    response = client.get(
        f"/expenses?user_id={user_id}"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["user_id"] == user_id


def test_filter_by_category(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_expense(
        client,
        user_id,
        category_id
    )

    response = client.get(
        f"/expenses?category_id={category_id}"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1
    assert data[0]["category_id"] == category_id


def test_filter_by_date(client):
    user_id = create_user(client)
    category_id = create_category(client)

    create_expense(
        client,
        user_id,
        category_id
    )

    response = client.get(
        "/expenses?start_date=2026-09-01&end_date=2026-09-30"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 1


def test_pagination(client):
    user_id = create_user(client)
    category_id = create_category(client)

    for amount in [100, 200, 300]:
        client.post(
            "/expenses",
            json={
                "user_id": user_id,
                "category_id": category_id,
                "amount": amount,
                "description": "Test expense",
                "expense_date": "2026-09-10"
            }
        )

    response = client.get(
        "/expenses?page=1&limit=2"
    )

    assert response.status_code == 200

    data = response.json()

    assert len(data) == 2